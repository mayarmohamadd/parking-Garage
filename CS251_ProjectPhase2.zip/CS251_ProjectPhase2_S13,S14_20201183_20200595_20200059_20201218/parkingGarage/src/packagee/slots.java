package packagee;

public class slots {
	private int slot_width;
	private int slot_depth;
	//private vechile list=new vechile();
	public slots(){
	}
	public void setSlotW(int w){
		slot_width=w;
	}
	public void setSlotD(int d){
		slot_depth=d;
	}
	public int getSlotW(){
		return slot_width;
	}
	public int getSlotD(){
		return slot_depth;
	}
	
}
