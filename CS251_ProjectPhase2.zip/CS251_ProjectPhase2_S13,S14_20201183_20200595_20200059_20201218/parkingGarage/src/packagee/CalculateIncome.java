package packagee;

public class CalculateIncome {
	owner o=new owner();
	public void calculateIncome(vechile c){
		System.out.println("Current Car = "+c.currentCar );
		System.out.println("Total Car=  "+c.totalCar);
		System.out.println("Total Income=  "+o.Totalincome);
	}
}
