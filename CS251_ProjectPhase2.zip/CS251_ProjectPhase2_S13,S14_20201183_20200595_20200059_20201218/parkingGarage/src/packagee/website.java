package packagee;
public interface website {
	public static vechile c=new vechile();
	display d=new display();
	enterData ent=new enterData();
	 void parkin(vechile[]arr,int s,slots[]a);
	 
}
